package org.personal.workoutlogger.dao;
import java.util.List;
import org.personal.workoutlogger.model.Workout;
import org.personal.workoutlogger.model.WorkoutItem;
public interface WorkoutDao {
  int createWorkout(Workout w);
  void addWorkoutItem(WorkoutItem item);
  java.util.List<Workout> getWorkoutsByUser(int userId);
  java.util.List<WorkoutItem> getItemsByWorkout(int workoutId);
  void deleteWorkout(int workoutId,int requesterUserId,boolean isTrainer);
}
